
import '../../../css/admin.css';

const AdminLayout = ({ children }: { children: React.ReactNode }) => {
    return ({children});
}
